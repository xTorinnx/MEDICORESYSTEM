package co.edu.unbosque.model;

public class FormulaDTO {

	private MedicamentoDTO medicamento;
	private int cantidad;

	public FormulaDTO() {
		// TODO Auto-generated constructor stub
	}

	public FormulaDTO(MedicamentoDTO medicamento, int cantidad) {
		super();
		this.medicamento = medicamento;
		this.cantidad = cantidad;
	}

	public MedicamentoDTO getMedicamento() {
		return medicamento;
	}

	public void setMedicamento(MedicamentoDTO medicamento) {
		this.medicamento = medicamento;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

}
