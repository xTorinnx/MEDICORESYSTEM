package co.edu.unbosque.persistence;

import java.io.IOException;
import java.util.ArrayList;

import co.edu.unbosque.json.MedicamentoJSON;
import co.edu.unbosque.model.MedicamentoDTO;

public class MedicamentoDAO implements ICrud{
	
	ArrayList<MedicamentoDTO> listaMedicamentos;

	@Override
	public String agregar(Object registro) {
		// TODO Auto-generated method stub
		String mensaje = null;
		int respuesta = 0;
		try {
			respuesta = MedicamentoJSON.postJSON((MedicamentoDTO) registro);
			mensaje = String.valueOf(respuesta);
			System.out.println("Respuesta:"+mensaje);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		
		return mensaje;
	}
	

	@Override
	public ArrayList<MedicamentoDTO> consultar() {
		// TODO Auto-generated method stub
		try {
			listaMedicamentos = MedicamentoJSON.getJSON();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaMedicamentos;
	}

	@Override
	public String actualizar(Object id, Object registro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String eliminar(Object id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object listar() {
		// TODO Auto-generated method stub
		return null;
	}

}
