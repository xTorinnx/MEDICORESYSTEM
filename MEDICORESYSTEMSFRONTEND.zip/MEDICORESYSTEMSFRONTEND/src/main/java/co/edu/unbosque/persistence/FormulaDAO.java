package co.edu.unbosque.persistence;

public class FormulaDAO {

}
