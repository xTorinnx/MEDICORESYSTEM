package co.edu.unbosque.json;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import co.edu.unbosque.model.FuncionarioDTO;

public class FuncionarioJSON {
	
	private static URL url;
	private static String sitio = "http://localhost:8088/";
	
    public static ArrayList<FuncionarioDTO> getJSON() throws IOException, ParseException {
        url = new URL(sitio + "funcionarios/listar");  // URL para listar los funcionarios
        HttpURLConnection http = (HttpURLConnection) url.openConnection();
        http.setRequestMethod("GET");  // Método GET para obtener los datos
        http.setRequestProperty("Accept", "application/json");  // Espera recibir JSON

        // Obtener la respuesta
        InputStream respuesta = http.getInputStream();
        byte[] inp = respuesta.readAllBytes();  // Leemos los bytes de la respuesta
        String json = new String(inp, StandardCharsets.UTF_8);  // Convertimos los bytes en una cadena JSON

        // Convertir el JSON en una lista de objetos FuncionarioDTO
        ArrayList<FuncionarioDTO> lista = parsingFuncionarios(json);

        http.disconnect();  // Cerramos la conexión HTTP
        return lista;  // Retornamos la lista de funcionarios
    }

    // Método para parsear el JSON y convertirlo en una lista de objetos FuncionarioDTO
    public static ArrayList<FuncionarioDTO> parsingFuncionarios(String json) throws ParseException {
        JSONParser jsonParser = new JSONParser();
        ArrayList<FuncionarioDTO> lista = new ArrayList<FuncionarioDTO>();
        
        // Parsear el JSON recibido (esperamos un arreglo de objetos JSON)
        JSONArray funcionarios = (JSONArray) jsonParser.parse(json);
        Iterator i = funcionarios.iterator();  // Iteramos sobre los objetos del arreglo

        while (i.hasNext()) {
            JSONObject innerObj = (JSONObject) i.next();
            FuncionarioDTO funcionario = new FuncionarioDTO();
            
            // Extraer los datos del JSON y asignarlos al objeto FuncionarioDTO
            funcionario.setCedula((double) innerObj.get("cedula"));  // Usamos un cast para convertir a double
            funcionario.setNombre(innerObj.get("nombre").toString());  // Convertimos a String
            funcionario.setClave(innerObj.get("clave").toString());
            lista.add(funcionario);  // Agregamos el funcionario a la lista
        }

        return lista;  // Retornamos la lista de funcionarios
    }
	
	public static int postJSON(FuncionarioDTO funcionario) throws IOException {
		url = new URL(sitio+"funcionarios/guardar");

		HttpURLConnection http;
		http = (HttpURLConnection)url.openConnection();
		try {
			http.setRequestMethod("POST");
		} catch (ProtocolException e) {
			e.printStackTrace();
		}
		http.setDoOutput(true);
		http.setRequestProperty("Accept", "application/json");
		http.setRequestProperty("Content-Type", "application/json");
		String data = "{"
				+ "\"cedula\":\""+ funcionario.getCedula()
				+"\",\"nombre\": \""+funcionario.getNombre()
				+"\",\"clave\": \""+funcionario.getClave()
				+ "\"}";
		byte[] out = data.getBytes(StandardCharsets.UTF_8);
		OutputStream stream = http.getOutputStream();
		stream.write(out);
		int respuesta = http.getResponseCode();
		http.disconnect();
		return respuesta;
	}
	
	public static int deleteJSON(double cedula) throws IOException {
		url = new URL(sitio + "funcionarios/eliminar/" + cedula);
		HttpURLConnection http = (HttpURLConnection) url.openConnection();
		try {
			http.setRequestMethod("DELETE");
		} catch (ProtocolException e) {
			e.printStackTrace();
		}
		http.setRequestProperty("Accept", "application/json");
		http.setDoOutput(true);
		int respuesta = http.getResponseCode();
		http.disconnect();
		return respuesta;
	}

}
