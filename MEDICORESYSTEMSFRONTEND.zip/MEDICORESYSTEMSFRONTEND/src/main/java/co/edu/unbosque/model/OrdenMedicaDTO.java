package co.edu.unbosque.model;

import java.util.ArrayList;

public class OrdenMedicaDTO {

	private int idEntidadSalud;
	private String nombreEntidadSalud; // longitud20
	private double docPaciente;
	private ArrayList<FormulaDTO> formula;
	private double idOrdenMedica;

	public OrdenMedicaDTO() {
		// TODO Auto-generated constructor stub
	}

	public OrdenMedicaDTO(int idEntidadSalud, String nombreEntidadSalud, double docPaciente,
			ArrayList<FormulaDTO> formula, double idOrdenMedica) {
		super();
		this.idEntidadSalud = idEntidadSalud;
		this.nombreEntidadSalud = nombreEntidadSalud;
		this.docPaciente = docPaciente;
		this.formula = formula;
		this.idOrdenMedica = idOrdenMedica;
	}

	public int getIdEntidadSalud() {
		return idEntidadSalud;
	}

	public void setIdEntidadSalud(int idEntidadSalud) {
		this.idEntidadSalud = idEntidadSalud;
	}

	public String getNombreEntidadSalud() {
		return nombreEntidadSalud;
	}

	public void setNombreEntidadSalud(String nombreEntidadSalud) {
		this.nombreEntidadSalud = nombreEntidadSalud;
	}

	public double getDocPaciente() {
		return docPaciente;
	}

	public void setDocPaciente(double docPaciente) {
		this.docPaciente = docPaciente;
	}

	public ArrayList<FormulaDTO> getFormula() {
		return formula;
	}

	public void setFormula(ArrayList<FormulaDTO> formula) {
		this.formula = formula;
	}

	public double getIdOrdenMedica() {
		return idOrdenMedica;
	}

	public void setIdOrdenMedica(double idOrdenMedica) {
		this.idOrdenMedica = idOrdenMedica;
	}

}
