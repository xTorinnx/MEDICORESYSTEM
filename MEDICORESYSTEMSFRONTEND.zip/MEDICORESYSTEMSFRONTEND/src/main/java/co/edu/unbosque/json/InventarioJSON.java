package co.edu.unbosque.json;

import java.io.IOException;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import co.edu.unbosque.model.InventarioDTO;

public class InventarioJSON {
	
	private static URL url;
	private static String sitio = "http://localhost:8088/";
	
    public static ArrayList<InventarioDTO> getJSON() throws IOException, ParseException {
        url = new URL(sitio + "inventarios/listar");  // URL para listar los funcionarios
        HttpURLConnection http = (HttpURLConnection) url.openConnection();
        http.setRequestMethod("GET");  // Método GET para obtener los datos
        http.setRequestProperty("Accept", "application/json");  // Espera recibir JSON

        // Obtener la respuesta
        InputStream respuesta = http.getInputStream();
        byte[] inp = respuesta.readAllBytes();  // Leemos los bytes de la respuesta
        String json = new String(inp, StandardCharsets.UTF_8);  // Convertimos los bytes en una cadena JSON

        // Convertir el JSON en una lista de objetos FuncionarioDTO
        ArrayList<InventarioDTO> lista = parsingInventarios(json);

        http.disconnect();  // Cerramos la conexión HTTP
        return lista;  // Retornamos la lista de funcionarios
    }

	
    public static ArrayList<InventarioDTO> parsingInventarios(String json) throws ParseException {
        JSONParser jsonParser = new JSONParser();
        ArrayList<InventarioDTO> lista = new ArrayList<InventarioDTO>();
        JSONArray inventarios = (JSONArray) jsonParser.parse(json);
        Iterator i = inventarios.iterator();
        
        while (i.hasNext()) {
            JSONObject innerObj = (JSONObject) i.next();
            InventarioDTO inventario = new InventarioDTO();

            // Parseamos los valores básicos de InventarioDTO
            inventario.setIdInventario((int) innerObj.get("idInventario"));
            inventario.setCantidad((int) innerObj.get("cantidad"));
            inventario.setTipoMovimiento(innerObj.get("tipoMovimiento").toString());

            // Solo obtenemos el idMedicamento, no el objeto completo de Medicamento
            inventario.setIdMedicamento((int) innerObj.get("idMedicamento"));

            lista.add(inventario);
        }
        return lista;
    }

	
    public static int postJSON(InventarioDTO inventario) throws IOException {
        url = new URL(sitio + "inventarios/guardar");

        HttpURLConnection http;
        http = (HttpURLConnection) url.openConnection();
        try {
            http.setRequestMethod("POST");
        } catch (ProtocolException e) {
            e.printStackTrace();
        }
        http.setDoOutput(true);
        http.setRequestProperty("Accept", "application/json");
        http.setRequestProperty("Content-Type", "application/json");

        // Construimos el JSON para enviar solo el idMedicamento (no el objeto completo)
        String data = "{"
                + "\"idInventario\": \"" + inventario.getIdInventario() + "\","
                + "\"idMedicamento\": \"" + inventario.getIdMedicamento() + "\","
                + "\"cantidad\": \"" + inventario.getCantidad() + "\","
                + "\"tipoMovimiento\": \"" + inventario.getTipoMovimiento() + "\""
                + "}";

        // Convertimos el JSON a bytes y lo enviamos
        byte[] out = data.getBytes(StandardCharsets.UTF_8);
        OutputStream stream = http.getOutputStream();
        stream.write(out);

        // Obtenemos el código de respuesta del servidor
        int respuesta = http.getResponseCode();
        http.disconnect();

        return respuesta;
    }
}
