package co.edu.unbosque.beans;

import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;

import org.primefaces.PrimeFaces;

import co.edu.unbosque.model.InventarioDTO;
import co.edu.unbosque.model.MedicamentoDTO;
import co.edu.unbosque.persistence.InventarioDAO;
import co.edu.unbosque.persistence.MedicamentoDAO;

@ManagedBean
public class InventarioBean {

	private int idInventario;
	private int cantidad;
	private String tipoMovimiento;
	private int idMedicamento;
	private String nombreMedicamento;
	private String presentacion;
	private double costo;
	private String resultado1;
	private String resultado2;
	private ArrayList<MedicamentoDTO> listaMedicamentos;
	private ArrayList<InventarioDTO> listaInventarios;
	private static int contador = 1;

	public void crearMedicamento() {
		if (this.cantidad <= 0) {
			FacesMessage errorMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
					"La cantidad debe ser mayor que 0.");
			PrimeFaces.current().dialog().showMessageDynamic(errorMessage);
		} else {
			MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
			InventarioDAO inventarioDAO = new InventarioDAO();
			MedicamentoDTO medicamentoDTO = new MedicamentoDTO(this.idMedicamento, this.nombreMedicamento, this.presentacion, this.costo);
			this.tipoMovimiento = "Entrada";
			this.resultado1 = medicamentoDAO.agregar(medicamentoDTO);
			int idMedicamento = medicamentoDTO.getIdMedicamento();
			
			
			
			this.resultado2 = inventarioDAO.agregar(
					new InventarioDTO(this.idInventario, contador++, this.cantidad, this.tipoMovimiento));
			if (this.resultado1.equals("200") && this.resultado2.equals("200")) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito",
						"Medicamento creado en el inventario exitosamente!");
				PrimeFaces.current().dialog().showMessageDynamic(message);

				PrimeFaces.current().executeScript(
						"setTimeout(function() { window.location.href = 'paginaAdministrador.xhtml'; }, 5000);");
			}
		}
	}



	public int getIdInventario() {
		return idInventario;
	}

	public void setIdInventario(int idInventario) {
		this.idInventario = idInventario;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public String getTipoMovimiento() {
		return tipoMovimiento;
	}

	public void setTipoMovimiento(String tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}

	public int getIdMedicamento() {
		return idMedicamento;
	}

	public void setIdMedicamento(int idMedicamento) {
		this.idMedicamento = idMedicamento;
	}

	public String getNombreMedicamento() {
		return nombreMedicamento;
	}

	public void setNombreMedicamento(String nombreMedicamento) {
		this.nombreMedicamento = nombreMedicamento;
	}

	public String getPresentacion() {
		return presentacion;
	}

	public void setPresentacion(String presentacion) {
		this.presentacion = presentacion;
	}

	public double getCosto() {
		return costo;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}


	public ArrayList<MedicamentoDTO> getListaMedicamentos() {
		return listaMedicamentos;
	}

	public void setListaMedicamentos(ArrayList<MedicamentoDTO> listaMedicamentos) {
		this.listaMedicamentos = listaMedicamentos;
	}

	public ArrayList<InventarioDTO> getListaInventarios() {
		return listaInventarios;
	}

	public void setListaInventarios(ArrayList<InventarioDTO> listaInventarios) {
		this.listaInventarios = listaInventarios;
	}

}
