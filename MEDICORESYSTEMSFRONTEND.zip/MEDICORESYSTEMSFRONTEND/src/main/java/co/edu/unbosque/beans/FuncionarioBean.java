package co.edu.unbosque.beans;




import java.io.IOException;
import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import co.edu.unbosque.model.FuncionarioDTO;
import co.edu.unbosque.persistence.FuncionarioDAO;

@ManagedBean
public class FuncionarioBean {
	
	private double cedula;
	private String nombre;
	private String clave;
	private String resultado;
	
	private ArrayList<FuncionarioDTO> listaFuncionarios;
	
	
	public String agregar() {
		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		this.resultado = funcionarioDAO.agregar(new FuncionarioDTO(this.cedula, this.nombre, this.clave));
		if(this.resultado.equals("200")) {
			this.listaFuncionarios = funcionarioDAO.consultar();
			return "index.xhtml";
		}
		return "error.xhtml";
	}
	
	public String login() throws IOException {
	    FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
	    // Consultamos todos los funcionarios
	    this.listaFuncionarios = funcionarioDAO.consultar();
	    
	    // Buscamos si hay un funcionario con la cédula y clave proporcionadas
	    for (FuncionarioDTO funcionario : listaFuncionarios) {
	        if (funcionario.getCedula() == this.cedula && funcionario.getClave().equals(this.clave)) {
	            // Si encontramos una coincidencia, el login es exitoso
	        	FacesContext.getCurrentInstance().getExternalContext().redirect("paginaAdministrador.xhtml");
	        }
	    }
	    
	    // Si no hay coincidencia, mostramos un mensaje de error
	    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login fallido", "Cédula o clave incorrectos"));
	    return null;  // Retorna null para permanecer en la misma página
	}


	public String consultar() {
	    FuncionarioDAO cl = new FuncionarioDAO();
	    this.listaFuncionarios = cl.consultar();
	    
	    if (this.listaFuncionarios != null && !this.listaFuncionarios.isEmpty()) {
	        System.out.println(this.listaFuncionarios);
	        // Si la consulta es exitosa, redirige a la vista "tablaFuncionario"
	        return "tablaFuncionario.xhtml";  // Nombre de la vista sin extensión .xhtml
	    } else {
	        // Si no se encuentran funcionarios, redirige a la página de error
	        return "error.xhtml";  // Nombre de la vista sin extensión .xhtml
	    }
	}


	
	public String eliminarFuncionario() {
	    try {
	        FuncionarioDTO funcionarioDTO = new FuncionarioDTO(this.cedula, this.nombre, this.clave);
	        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
	        resultado = funcionarioDAO.eliminar(funcionarioDTO);
	        this.listaFuncionarios = funcionarioDAO.consultar();
	        if (resultado.equals("200")) {
	            return "tablaFuncionarios.xhtml";
	        }
	    } catch (Exception e) {
	        System.out.println("Error al eliminar funcionario: " + e.getMessage());
	        e.printStackTrace();
	    }
	    return "error.xhtml";
	}
	


	public double getCedula() {
		return cedula;
	}

	public void setCedula(double cedula) {
		this.cedula = cedula;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public ArrayList<FuncionarioDTO> getListaFuncionarios() {
		return listaFuncionarios;
	}

	public void setListaFuncionarios(ArrayList<FuncionarioDTO> listaFuncionarios) {
		this.listaFuncionarios = listaFuncionarios;
	}
	

	
	

}
