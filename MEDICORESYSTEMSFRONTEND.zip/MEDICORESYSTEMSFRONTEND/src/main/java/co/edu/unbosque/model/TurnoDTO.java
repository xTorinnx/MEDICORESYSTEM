package co.edu.unbosque.model;



public class TurnoDTO {
	
	private int idTurno;
	
	private double docPaciente;
	
	private int caja;
	
	private String estado;// longitud 1
	
	private int numTurno;

	public TurnoDTO() {
		super();
	}

	public TurnoDTO(int idTurno, double docPaciente, int caja, String estado, int numTurno) {
		super();
		this.idTurno = idTurno;
		this.docPaciente = docPaciente;
		this.caja = caja;
		this.estado = estado;
		this.numTurno = numTurno;
	}

	public int getIdTurno() {
		return idTurno;
	}

	public void setIdTurno(int idTurno) {
		this.idTurno = idTurno;
	}

	public double getDocPaciente() {
		return docPaciente;
	}

	public void setDocPaciente(double docPaciente) {
		this.docPaciente = docPaciente;
	}

	public int getCaja() {
		return caja;
	}

	public void setCaja(int caja) {
		this.caja = caja;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public int getNumTurno() {
		return numTurno;
	}

	public void setNumTurno(int numTurno) {
		this.numTurno = numTurno;
	}

}
