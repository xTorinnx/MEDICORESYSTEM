package co.edu.unbosque.persistence;

import java.io.IOException;
import java.util.ArrayList;

import co.edu.unbosque.json.FuncionarioJSON;
import co.edu.unbosque.json.TurnoJSON;
import co.edu.unbosque.model.FuncionarioDTO;
import co.edu.unbosque.model.TurnoDTO;

public class TurnoDAO implements ICrud{
	
	private ArrayList<TurnoDTO> listaTurnos;

	@Override
	public String agregar(Object registro) {
		// TODO Auto-generated method stub
		String mensaje = null;
		int respuesta = 0;
		try {
			respuesta = TurnoJSON.postJSON((TurnoDTO) registro);
			mensaje = String.valueOf(respuesta);
			System.out.println("Respuesta:"+mensaje);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		
		return mensaje;
	}
	

	@Override
	public ArrayList<TurnoDTO> consultar() {
		// TODO Auto-generated method stub
		try {
			listaTurnos = TurnoJSON.getJSON();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaTurnos;
	}

	@Override
	public String actualizar(Object id, Object registro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String eliminar(Object id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object listar() {
		// TODO Auto-generated method stub
		return null;
	}

}
