package co.edu.unbosque.model;




public class InventarioDTO {

	private int idInventario;
	
	private int idMedicamento;
	
	private int cantidad;
	
	private String tipoMovimiento;// Longitud 1

	public InventarioDTO() {
		super();
	}

	public InventarioDTO(int idInventario, int idMedicamento, int cantidad, String tipoMovimiento) {
		super();
		this.idInventario = idInventario;
		this.idMedicamento = idMedicamento;
		this.cantidad = cantidad;
		this.tipoMovimiento = tipoMovimiento;
	}

	public int getIdInventario() {
		return idInventario;
	}

	public void setIdInventario(int idInventario) {
		this.idInventario = idInventario;
	}

	public int getIdMedicamento() {
		return idMedicamento;
	}

	public void setIdMedicamento(int idMedicamento) {
		this.idMedicamento = idMedicamento;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public String getTipoMovimiento() {
		return tipoMovimiento;
	}

	public void setTipoMovimiento(String tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}

}
