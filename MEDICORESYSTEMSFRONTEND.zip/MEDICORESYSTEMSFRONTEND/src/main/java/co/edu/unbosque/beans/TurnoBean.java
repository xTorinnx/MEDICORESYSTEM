package co.edu.unbosque.beans;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

import javax.faces.bean.ManagedBean;

import co.edu.unbosque.model.TurnoDTO;
import co.edu.unbosque.persistence.TurnoDAO;

@ManagedBean
public class TurnoBean {
	private Random random;
	
	private int idTurno;
	
	private double docPaciente;
	
	private int caja;
	
    private static int numTurnoIncrementable = 1;
	
	private String estado;
	
	private int numTurno;
	
	private String resultado;
	
	private ArrayList<TurnoDTO> listaTurnos;
	
	public String agregarTurno() {
		random = new Random();
		
		TurnoDAO turnoDAO = new TurnoDAO();
		this.caja = random.nextInt(6) + 1;
		this.estado = "Atender";
		this.numTurno = aumentarNumTurno();	
		this.resultado = turnoDAO.agregar(new TurnoDTO(this.idTurno, this.docPaciente, this.caja, this.estado, this.numTurno));

		
		this.listaTurnos = turnoDAO.consultar();
		if (resultado.equals("200")) {
			return "mostrarTurno.xhtml";
		}
		return "error.xhtml";
	}
		
	public String getDocPacienteString() {
		DecimalFormat df = new DecimalFormat("#.##"); // Adjust the pattern if needed
		return df.format(docPaciente);
	}
	
	public int aumentarNumTurno() {
		return numTurnoIncrementable++;
	}

	public int getIdTurno() {
		return idTurno;
	}

	public void setIdTurno(int idTurno) {
		this.idTurno = idTurno;
	}

	public double getDocPaciente() {
		return docPaciente;
	}

	public void setDocPaciente(double docPaciente) {
		this.docPaciente = docPaciente;
	}

	public int getCaja() {
		return caja;
	}

	public void setCaja(int caja) {
		this.caja = caja;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public int getNumTurno() {
		return numTurno;
	}

	public void setNumTurno(int numTurno) {
		this.numTurno = numTurno;
	}
	
	

	
	

}
