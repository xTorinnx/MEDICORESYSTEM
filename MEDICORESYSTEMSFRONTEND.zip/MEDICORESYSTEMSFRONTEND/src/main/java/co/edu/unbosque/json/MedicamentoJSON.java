package co.edu.unbosque.json;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import co.edu.unbosque.model.FuncionarioDTO;
import co.edu.unbosque.model.MedicamentoDTO;

public class MedicamentoJSON {
	
	private static URL url;
	private static String sitio = "http://localhost:8088/";
	
    public static ArrayList<MedicamentoDTO> getJSON() throws IOException, ParseException {
        url = new URL(sitio + "medicamentos/listar");  // URL para listar los funcionarios
        HttpURLConnection http = (HttpURLConnection) url.openConnection();
        http.setRequestMethod("GET");  // Método GET para obtener los datos
        http.setRequestProperty("Accept", "application/json");  // Espera recibir JSON

        // Obtener la respuesta
        InputStream respuesta = http.getInputStream();
        byte[] inp = respuesta.readAllBytes();  // Leemos los bytes de la respuesta
        String json = new String(inp, StandardCharsets.UTF_8);  // Convertimos los bytes en una cadena JSON

        // Convertir el JSON en una lista de objetos FuncionarioDTO
        ArrayList<MedicamentoDTO> lista = parsingMedicamentos(json);

        http.disconnect();  // Cerramos la conexión HTTP
        return lista;  // Retornamos la lista de funcionarios
    }

	
	public static ArrayList<MedicamentoDTO> parsingMedicamentos(String json) throws ParseException {
        JSONParser jsonParser = new JSONParser();
        ArrayList<MedicamentoDTO> lista = new ArrayList<MedicamentoDTO>();
        JSONArray turnos = (JSONArray) jsonParser.parse(json);
        Iterator i = turnos.iterator();
        while (i.hasNext()) {
            JSONObject innerObj = (JSONObject) i.next();
            MedicamentoDTO medicamento = new MedicamentoDTO();
            medicamento.setIdMedicamento((int) innerObj.get("idMedicamento"));
            medicamento.setNombreMedicamento(innerObj.get("nombreMedicamento").toString());
            medicamento.setPresentacion( innerObj.get("presentacion").toString());
            medicamento.setCosto((int)innerObj.get("costo"));
            

            lista.add(medicamento);
        }
        return lista;
	}
	
	public static int postJSON(MedicamentoDTO medicamento) throws IOException {
		url = new URL(sitio+"medicamentos/guardar");

		HttpURLConnection http;
		http = (HttpURLConnection)url.openConnection();
		try {
			http.setRequestMethod("POST");
		} catch (ProtocolException e) {
			e.printStackTrace();
		}
		http.setDoOutput(true);
		http.setRequestProperty("Accept", "application/json");
		http.setRequestProperty("Content-Type", "application/json");
		String data = "{"
				+ "\"idMedicamento\":\""+ medicamento.getIdMedicamento()
				+"\",\"nombreMedicamento\": \""+medicamento.getNombreMedicamento()
				+"\",\"presentacion\": \""+medicamento.getPresentacion()
				+"\",\"costo\": \""+medicamento.getCosto()
				+ "\"}";
		byte[] out = data.getBytes(StandardCharsets.UTF_8);
		OutputStream stream = http.getOutputStream();
		stream.write(out);
		int respuesta = http.getResponseCode();
		http.disconnect();
		return respuesta;
	}

}
