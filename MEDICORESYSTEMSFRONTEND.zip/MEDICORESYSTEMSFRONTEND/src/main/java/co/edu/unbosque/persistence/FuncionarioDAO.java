package co.edu.unbosque.persistence;

import java.io.IOException;

import java.util.ArrayList;
import co.edu.unbosque.json.FuncionarioJSON;
import co.edu.unbosque.model.FuncionarioDTO;



public class FuncionarioDAO implements ICrud{
	
	private ArrayList<FuncionarioDTO> listaFuncionarios;

	@Override
	public String agregar(Object registro) {
		// TODO Auto-generated method stub
		String mensaje = null;
		int respuesta = 0;
		try {
			respuesta = FuncionarioJSON.postJSON((FuncionarioDTO) registro);
			mensaje = String.valueOf(respuesta);
			System.out.println("Respuesta:"+mensaje);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		
		return mensaje;
	}

	@Override
	public ArrayList<FuncionarioDTO> consultar() {
		try {
			listaFuncionarios = FuncionarioJSON.getJSON();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaFuncionarios;
	}

	@Override
	public String actualizar(Object id, Object registro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String eliminar(Object id) {
		// TODO Auto-generated method stub
		 String mensaje = null;
	        int respuesta = 0;
	        try {
	            double cedula = (double) id;
	            respuesta = FuncionarioJSON.deleteJSON(cedula);
	            if (respuesta == 200) {
	                mensaje = "Funcionario eliminado exitosamente.";
	            } else {
	                mensaje = "Error al eliminar el funcionario.";
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	            mensaje = "Error en la conexión con el servidor.";
	        }
	        return mensaje;
	}

	@Override
	public Object listar() {
		// TODO Auto-generated method stub
		return null;
	}

}
