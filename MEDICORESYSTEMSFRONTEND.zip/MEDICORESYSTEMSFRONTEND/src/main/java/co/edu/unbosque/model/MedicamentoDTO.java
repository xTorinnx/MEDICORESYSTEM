package co.edu.unbosque.model;


public class MedicamentoDTO {
	

	private int idMedicamento;
	
	private String nombreMedicamento;// longitud 50
	
	private String presentacion; // longitud 20
	
	private double costo;

	public MedicamentoDTO() {
		super();
	}

	public MedicamentoDTO(int idMedicamento, String nombreMedicamento, String presentacion, double costo) {
		super();
		this.idMedicamento = idMedicamento;
		this.nombreMedicamento = nombreMedicamento;
		this.presentacion = presentacion;
		this.costo = costo;
	}

	public int getIdMedicamento() {
		return idMedicamento;
	}

	public void setIdMedicamento(int idMedicamento) {
		this.idMedicamento = idMedicamento;
	}

	public String getNombreMedicamento() {
		return nombreMedicamento;
	}

	public void setNombreMedicamento(String nombreMedicamento) {
		this.nombreMedicamento = nombreMedicamento;
	}

	public String getPresentacion() {
		return presentacion;
	}

	public void setPresentacion(String presentacion) {
		this.presentacion = presentacion;
	}

	public double getCosto() {
		return costo;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}

}
